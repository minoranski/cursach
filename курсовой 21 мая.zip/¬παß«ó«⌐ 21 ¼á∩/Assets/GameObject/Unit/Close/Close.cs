using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Close : Unit
{
    // Start is called before the first frame update
    void Start()
    {
        AttackDistance = 100;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
