using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildControl : MonoBehaviour
{
     public bool isSelect = false;
     public GameObject panel = null; 

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(isSelect)
            panel.SetActive(true);
            else 
            panel.SetActive(false);
    }
}
